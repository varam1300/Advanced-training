package problemstmt1_2;

public class Rectangle1_2 {
	
	public int length;
	public int breadth;
	public int area;


	//default constructor
	public Rectangle1_2() {
	}


	//Constructor
	public Rectangle1_2(int length, int breadth) {
		this.length = length;
		this.breadth = breadth;
	}
	
	//find area of rectangle
	public void printArea() {
		area = length * breadth;
		System.out.println("Area of Rectangle1_2 : " + area);
	}

// display all data of rectangle
	public void printData() {
		System.out.println("Length of Rectangle1_2 is : " + length);
		System.out.println("Breadth of Rectangle1_2 is : " + breadth);
	
	}

}
